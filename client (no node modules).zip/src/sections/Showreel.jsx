import Reveal from '../components/Reveal';
import SectionEyebrow from '../components/SectionEyebrow';
import ProjectCard from '../components/ProjectCard';
import MagneticButton from '../components/MagneticButton';
import projects from '../utils/projects';
import { ArrowUpRight } from 'lucide-react';

const YOUTUBE_URL = 'https://www.youtube.com/@rexo_ae';

export default function Showreel() {
  return (
    <section id="showreel" className="relative px-6 py-28 sm:py-36 max-w-6xl mx-auto">
      <SectionEyebrow index="03" label="Showreel" />

      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6 mb-14">
        <Reveal>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tightest text-white max-w-lg">
            Selected work, across formats.
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="text-sm text-paper-dim max-w-xs">
            A cross-section of cinematic and social edits. Click any project
            to watch it on YouTube or Instagram.
          </p>
        </Reveal>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 auto-rows-[280px] gap-5 max-w-3xl mx-auto">
        {projects.map((project, i) => (
          <ProjectCard key={project.id} project={project} index={i} />
        ))}
      </div>

      <Reveal delay={0.15} className="flex justify-center mt-12">
        <MagneticButton
          as="a"
          href={YOUTUBE_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="group flex items-center gap-2 glass text-white font-medium text-sm px-6 py-3.5 rounded-full"
        >
          View more
          <ArrowUpRight size={16} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </MagneticButton>
      </Reveal>
    </section>
  );
}