import Reveal from '../components/Reveal';
import SectionEyebrow from '../components/SectionEyebrow';
import AnimatedStat from '../components/AnimatedStat';

const STATS = [
  { value: 20, prefix: '', suffix: '+', label: 'Projects Completed' },
  { value: 9, prefix: '', suffix: '.2/10', label: 'Client Satisfaction' },
  { value: 300, prefix: '', suffix: '+', label: 'YouTube Subscribers' },
  { value: 3, prefix: '', suffix: 'M+', label: 'Views Reached' },
];
export default function Achievements() {
  return (
    <section id="achievements" className="relative px-6 py-28 sm:py-36 max-w-6xl mx-auto">
      <SectionEyebrow index="02" label="Achievements" />
      <Reveal>
        <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tightest text-white max-w-lg">
          Numbers that reflect the work.
        </h2>
      </Reveal>

      <div className="mt-12 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-5">
        {STATS.map((stat, i) => (
          <AnimatedStat key={stat.label} index={i} {...stat} />
        ))}
      </div>
    </section>
  );
}
