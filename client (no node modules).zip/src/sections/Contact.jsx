import { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Instagram, Mail, Youtube, ArrowUpRight, Check } from 'lucide-react';
import Reveal from '../components/Reveal';
import SectionEyebrow from '../components/SectionEyebrow';
import MagneticButton from '../components/MagneticButton';
import FloatingLights from '../components/FloatingLights';

const SOCIALS = [
  { label: 'Discord', handle: 'rexo_ae', href: null, Icon: MessageCircle },
  { label: 'Instagram', handle: '@rexoofc', href: 'https://instagram.com/rexoofc', Icon: Instagram },
  { label: 'Email', handle: 'rexo.aeofficial@gmail.com', href: 'https://mail.google.com/mail/?view=cm&fs=1&to=rexo.aeofficial@gmail.com&su=Let%27s%20work%20together&body=Hey%2C%20I%20wanna%20hire%20you!', Icon: Mail },
  { label: 'YouTube', handle: '@rexo_ae', href: 'https://www.youtube.com/@rexo_ae', Icon: Youtube },
];

export default function Contact() {
  const [copied, setCopied] = useState(false);

  function handleCopyDiscord(handle) {
    navigator.clipboard?.writeText(handle).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  }

  return (
    <section id="contact" className="relative px-6 py-28 sm:py-36 max-w-6xl mx-auto overflow-hidden">
      <FloatingLights className="opacity-60" />
      <SectionEyebrow index="05" label="Contact" />

      <Reveal>
        <h2 className="font-display text-3xl sm:text-4xl md:text-6xl font-semibold tracking-tightest text-white max-w-2xl leading-[1.05]">
          Let&apos;s create something amazing.
        </h2>
      </Reveal>

      <div className="mt-16 grid sm:grid-cols-2 gap-5">
        {SOCIALS.map((social, i) => {
          const isDiscord = !social.href;
          return (
            <MagneticButton
              key={social.label}
              as={isDiscord ? 'button' : 'a'}
              href={social.href || undefined}
              target={isDiscord ? undefined : '_blank'}
              rel={isDiscord ? undefined : 'noopener noreferrer'}
              onClick={isDiscord ? () => handleCopyDiscord(social.handle) : undefined}
              className="w-full text-left"
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
                className="glass rounded-2xl p-6 flex items-center justify-between shadow-glass hover:bg-white/[0.06] transition-colors duration-300"
              >
                <div className="flex items-center gap-4">
                  <div className="h-11 w-11 rounded-full glass-strong flex items-center justify-center shrink-0">
                    <social.Icon size={18} className="text-white/85" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{social.label}</p>
                    <p className="text-xs text-paper-dim mt-0.5 break-all">
                      {isDiscord && copied ? 'Copied to clipboard' : social.handle}
                    </p>
                  </div>
                </div>
                {isDiscord ? (
                  <Check size={18} className={`text-paper-faint shrink-0 transition-opacity ${copied ? 'opacity-100' : 'opacity-0'}`} />
                ) : (
                  <ArrowUpRight size={18} className="text-paper-faint shrink-0" />
                )}
              </motion.div>
            </MagneticButton>
          );
        })}
      </div>
    </section>
  );
}