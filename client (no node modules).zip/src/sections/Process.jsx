import { motion } from 'framer-motion';
import Reveal from '../components/Reveal';
import SectionEyebrow from '../components/SectionEyebrow';
import { padIndex } from '../utils/format';

const STEPS = [
  { title: 'Receive Brief', copy: 'Understanding the goal, audience, and platform.' },
  { title: 'Research & Planning', copy: 'Studying references and mapping the structure.' },
  { title: 'Editing', copy: 'Building the core cut — pacing, rhythm, story.' },
  { title: 'Motion Graphics & Sound Design', copy: 'Layering visual and audio texture.' },
  { title: 'Revisions', copy: 'Refining based on feedback, frame by frame.' },
  { title: 'Final Delivery', copy: 'Exporting and handing off the finished edit.' },
];

export default function Process() {
  return (
    <section id="process" className="relative px-6 py-28 sm:py-36 max-w-6xl mx-auto">
      <SectionEyebrow index="04" label="Editing Process" />
      <Reveal>
        <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tightest text-white max-w-lg mb-16 sm:mb-20">
          Six steps, one story.
        </h2>
      </Reveal>

      {/* Desktop: horizontal timeline */}
      <div className="hidden md:block relative">
        <div className="absolute top-[22px] left-0 right-0 h-px bg-white/10" />
        <motion.div
          className="absolute top-[22px] left-0 h-px bg-white/50 origin-left"
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true, margin: '-20% 0px' }}
          transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
        />
        <div className="grid grid-cols-6 gap-4">
          {STEPS.map((step, i) => (
            <Reveal key={step.title} delay={i * 0.08}>
              <div className="relative pt-14">
                <div className="absolute top-0 left-0 h-11 w-11 rounded-full glass-strong flex items-center justify-center">
                  <span className="font-mono text-xs text-white/80">{padIndex(i + 1)}</span>
                </div>
                <h3 className="font-display text-sm font-medium text-white leading-snug">
                  {step.title}
                </h3>
                <p className="mt-2 text-xs text-paper-dim leading-relaxed">{step.copy}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      {/* Mobile: vertical timeline */}
      <div className="md:hidden relative pl-10">
        <div className="absolute top-2 bottom-2 left-[19px] w-px bg-white/10" />
        <div className="flex flex-col gap-10">
          {STEPS.map((step, i) => (
            <Reveal key={step.title} delay={i * 0.06} className="relative">
              <div className="absolute -left-10 top-0 h-9 w-9 rounded-full glass-strong flex items-center justify-center">
                <span className="font-mono text-[11px] text-white/80">{padIndex(i + 1)}</span>
              </div>
              <h3 className="font-display text-sm font-medium text-white">{step.title}</h3>
              <p className="mt-1.5 text-xs text-paper-dim leading-relaxed max-w-xs">{step.copy}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
