/**
 * Showreel project data.
 *
 * Replace `thumbnail`, `url`, and the copy below with your own work.
 * - `platform` accepts "youtube" or "instagram" and controls the badge.
 * - `thumbnail` can be a local import (place files in /src/assets and
 *   import them above) or a remote URL.
 * - Leave `thumbnail` as null to fall back to the generated placeholder.
 */
const projects = [
  {
    id: 'proj-01',
    title: 'Creative Effects Edit',
    platform: 'youtube',
    description: 'Fast-paced phonk edit paired with kinetic typography.',
    thumbnail: 'https://img.youtube.com/vi/EwXanHmtPvE/hqdefault.jpg',
    url: 'https://www.youtube.com/shorts/EwXanHmtPvE',
    size: 'medium',
  },
  {
    id: 'proj-02',
    title: 'Cinematic Smooth Edit',
    platform: 'youtube',
    description: 'A cinematic edit blending narrative pacing with color-graded visuals.',
    thumbnail: 'https://img.youtube.com/vi/KNq0chZ24bk/hqdefault.jpg',
    url: 'https://www.youtube.com/shorts/KNq0chZ24bk',
    size: 'medium',
  },
];

export default projects;