import { motion } from 'framer-motion';
import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import useScrollSpy from '../hooks/useScrollSpy';
import { formatTimecode } from '../utils/format';

const LINKS = [
  { id: 'about', label: 'About' },
  { id: 'achievements', label: 'Stats' },
  { id: 'showreel', label: 'Work' },
  { id: 'process', label: 'Process' },
  { id: 'contact', label: 'Contact' },
];

function scrollToId(id) {
  const el = document.getElementById(id);
  if (el) {
    el.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  }
}

export default function GlassNav() {
  const { activeId, progress } = useScrollSpy(LINKS.map((l) => l.id));
  const [open, setOpen] = useState(false);

  return (
    <motion.header
      initial={{ y: -30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      className="fixed top-4 inset-x-0 z-50 flex justify-center px-4"
    >
      <div className="w-full max-w-5xl">
        <div className="glass-strong rounded-2xl px-5 py-3 flex items-center justify-between shadow-glass">
          {/* Logo */}
          <a
            href="#top"
            data-cursor="link"
            onClick={(e) => {
              e.preventDefault();
              scrollToId('top');
            }}
            className="font-display font-semibold tracking-tight text-sm sm:text-base text-white"
          >
            Rexo
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {LINKS.map((link) => (
              <button
                key={link.id}
                data-cursor="link"
                onClick={() => scrollToId(link.id)}
                className={`relative px-4 py-2 text-xs tracking-wide rounded-full transition-colors duration-300 ${
                  activeId === link.id
                    ? 'text-white'
                    : 'text-paper-dim hover:text-white'
                }`}
              >
                {activeId === link.id && (
                  <motion.span
                    layoutId="nav-pill"
                    className="absolute inset-0 rounded-full bg-white/10 border border-white/10"
                    transition={{
                      type: 'spring',
                      stiffness: 380,
                      damping: 30,
                    }}
                  />
                )}
                <span className="relative">{link.label}</span>
              </button>
            ))}
          </nav>

          {/* Scroll Progress */}
          <div className="hidden md:flex items-center gap-2 font-mono text-[11px] text-paper-dim tabular-nums">
            <span className="text-white/70">
              {formatTimecode(progress)}
            </span>

            <div className="relative h-[3px] w-16 rounded-full bg-white/10 overflow-hidden">
              <motion.div
                className="absolute inset-y-0 left-0 bg-white/60"
                style={{ width: `${progress * 100}%` }}
              />
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            data-cursor="link"
            className="md:hidden text-white"
            aria-label={open ? 'Close menu' : 'Open menu'}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
            className="md:hidden mt-2 glass-strong rounded-2xl p-4 flex flex-col gap-1 shadow-glass"
          >
            {LINKS.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  scrollToId(link.id);
                  setOpen(false);
                }}
                className={`text-left px-3 py-2.5 rounded-lg text-sm transition-colors ${
                  activeId === link.id
                    ? 'text-white bg-white/10'
                    : 'text-paper-dim hover:text-white'
                }`}
              >
                {link.label}
              </button>
            ))}
          </motion.div>
        )}
      </div>
    </motion.header>
  );
}