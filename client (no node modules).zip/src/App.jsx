import { useEffect, useState } from 'react';
import useLenis from './hooks/useLenis';
import CustomCursor from './components/CustomCursor';
import GlassNav from './components/GlassNav';
import PageLoader from './components/PageLoader';
import Home from './pages/Home';

export default function App() {
  useLenis();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 700);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <PageLoader visible={loading} />
      <div className="grain" />
      <CustomCursor />
      <GlassNav />
      <Home />
    </>
  );
}
